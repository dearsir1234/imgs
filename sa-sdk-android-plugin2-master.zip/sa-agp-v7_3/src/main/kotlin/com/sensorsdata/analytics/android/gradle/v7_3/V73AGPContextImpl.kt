package com.sensorsdata.analytics.android.gradle.v7_3

import com.sensorsdata.analytics.android.gradle.AGPContext
import com.sensorsdata.analytics.android.gradle.AsmCompatFactory

object V73AGPContextImpl : AGPContext {
    override var asmCompatFactory: AsmCompatFactory? = null
}