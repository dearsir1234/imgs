./gradlew clean
./gradlew :gradle_portal_plugin:build
./gradlew :sa-agp-api:build
./gradlew :sa-agp-legacy:build
./gradlew :sa-agp-v7_3:build
./gradlew :sa-agp-compat:build
./gradlew :sa-gradle-plugin:build
./gradlew publish