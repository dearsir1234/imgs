package com.sensorsdata.analytics.android.plugin.utils

object TextUtil {
    fun isEmpty(str: CharSequence?): Boolean {
        return str.isNullOrEmpty()
    }
}