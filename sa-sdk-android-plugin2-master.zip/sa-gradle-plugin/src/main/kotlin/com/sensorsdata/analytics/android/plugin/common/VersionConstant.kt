package com.sensorsdata.analytics.android.plugin.common

object VersionConstant {
    //Plugin Version
    const val VERSION = "4.0.2"
    // MIN SDK Version
    const val MIN_SDK_VERSION = "6.6.9"
}